import { TestSection, PracticeQuestion, StudyPlan, TestDate, BlogPost, FAQ } from '../types';

export const testSections: TestSection[] = [
  {
    id: 'reading',
    title: 'Reading',
    description: 'Tests your ability to understand and analyze written passages',
    duration: 65,
    questions: 52,
    topics: ['Literature', 'History/Social Studies', 'Science', 'Paired Passages']
  },
  {
    id: 'writing',
    title: 'Writing and Language',
    description: 'Measures your ability to revise and edit text',
    duration: 35,
    questions: 44,
    topics: ['Standard English Conventions', 'Expression of Ideas', 'Command of Evidence']
  },
  {
    id: 'math',
    title: 'Mathematics',
    description: 'Tests problem-solving skills in algebra, geometry, and trigonometry',
    duration: 80,
    questions: 58,
    topics: ['Algebra', 'Problem Solving', 'Advanced Math', 'Geometry', 'Trigonometry']
  }
];

export const practiceQuestions: PracticeQuestion[] = [
  {
    id: '1',
    section: 'math',
    question: 'If 3x + 5 = 20, what is the value of x?',
    options: ['3', '5', '7', '15'],
    correctAnswer: 1,
    explanation: 'Subtract 5 from both sides: 3x = 15. Then divide by 3: x = 5.',
    difficulty: 'easy'
  },
  {
    id: '2',
    section: 'reading',
    question: 'What is the main purpose of the passage?',
    options: [
      'To describe a scientific discovery',
      'To argue for environmental protection',
      'To explain a historical event',
      'To analyze literary techniques'
    ],
    correctAnswer: 1,
    explanation: 'The passage primarily advocates for environmental conservation through compelling evidence and examples.',
    difficulty: 'medium'
  },
  {
    id: '3',
    section: 'math',
    question: 'A circle has a radius of 6 units. What is its area?',
    options: ['12π', '36π', '18π', '24π'],
    correctAnswer: 1,
    explanation: 'Area of a circle = πr². With r = 6, Area = π(6)² = 36π square units.',
    difficulty: 'medium'
  },
  {
    id: '4',
    section: 'writing',
    question: 'Which sentence demonstrates correct parallel structure?',
    options: [
      'She likes reading, writing, and to paint.',
      'She likes reading, writing, and painting.',
      'She likes to read, writing, and painting.',
      'She likes reading, to write, and painting.'
    ],
    correctAnswer: 1,
    explanation: 'Parallel structure requires consistent grammatical forms. "Reading, writing, and painting" are all gerunds.',
    difficulty: 'easy'
  },
  {
    id: '5',
    section: 'math',
    question: 'If f(x) = 2x + 3, what is f(4)?',
    options: ['8', '11', '14', '5'],
    correctAnswer: 1,
    explanation: 'Substitute x = 4 into the function: f(4) = 2(4) + 3 = 8 + 3 = 11.',
    difficulty: 'easy'
  },
  {
    id: '6',
    section: 'reading',
    question: 'Based on the context, what does "ubiquitous" most likely mean?',
    options: ['Rare and valuable', 'Present everywhere', 'Difficult to understand', 'Recently discovered'],
    correctAnswer: 1,
    explanation: 'Context clues suggest something that appears frequently or is found in many places, meaning "present everywhere".',
    difficulty: 'medium'
  }
];

export const studyPlans: StudyPlan[] = [
  {
    id: '1',
    title: '3-Month Intensive Plan',
    duration: '12 weeks',
    description: 'Comprehensive preparation for significant score improvement',
    tasks: [
      'Take diagnostic test to identify strengths and weaknesses',
      'Focus on weakest sections first with targeted practice',
      'Complete 2 practice tests per week with full timing',
      'Review all incorrect answers with detailed explanations',
      'Master test-taking strategies and time management',
      'Take final practice test under real conditions'
    ]
  },
  {
    id: '2',
    title: '6-Week Quick Prep',
    duration: '6 weeks',
    description: 'Efficient preparation for students with limited time',
    tasks: [
      'Identify key weakness areas through diagnostic assessment',
      'Practice high-yield question types and common patterns',
      'Master essential test-taking strategies and shortcuts',
      'Take 3 full practice tests with detailed review',
      'Focus on timing improvement and pacing strategies',
      'Final review of most challenging concepts'
    ]
  },
  {
    id: '3',
    title: '1-Month Crash Course',
    duration: '4 weeks',
    description: 'Last-minute preparation focusing on high-impact strategies',
    tasks: [
      'Quick diagnostic to prioritize study areas',
      'Focus on test-taking strategies over content review',
      'Practice timing with section-specific drills',
      'Take 2 full practice tests with analysis',
      'Review common mistake patterns',
      'Final confidence-building practice session'
    ]
  }
];

export const testDates: TestDate[] = [
  {
    date: 'March 9, 2024',
    registrationDeadline: 'February 9, 2024',
    lateRegistrationDeadline: 'February 23, 2024'
  },
  {
    date: 'May 4, 2024',
    registrationDeadline: 'April 4, 2024',
    lateRegistrationDeadline: 'April 18, 2024'
  },
  {
    date: 'June 1, 2024',
    registrationDeadline: 'May 2, 2024',
    lateRegistrationDeadline: 'May 16, 2024'
  },
  {
    date: 'August 24, 2024',
    registrationDeadline: 'July 25, 2024',
    lateRegistrationDeadline: 'August 8, 2024'
  },
  {
    date: 'October 5, 2024',
    registrationDeadline: 'September 5, 2024',
    lateRegistrationDeadline: 'September 19, 2024'
  },
  {
    date: 'November 2, 2024',
    registrationDeadline: 'October 3, 2024',
    lateRegistrationDeadline: 'October 17, 2024'
  }
];

export const blogPosts: BlogPost[] = [
  {
    id: '1',
    title: '10 Essential SAT Math Formulas You Must Know',
    excerpt: 'Master these key formulas to boost your math section score significantly. From quadratic equations to trigonometric identities, these formulas are your ticket to success.',
    date: 'Feb 15, 2024',
    readTime: '5 min read',
    category: 'Math Tips'
  },
  {
    id: '2',
    title: 'How to Improve Reading Comprehension Speed',
    excerpt: 'Proven strategies to read faster while maintaining comprehension. Learn active reading techniques that top scorers use to tackle dense passages efficiently.',
    date: 'Feb 12, 2024',
    readTime: '7 min read',
    category: 'Reading Strategies'
  },
  {
    id: '3',
    title: 'Test Day Success: What to Expect and How to Prepare',
    excerpt: 'Complete guide to performing your best on the actual test day. From what to bring to managing test anxiety, we cover everything you need to know.',
    date: 'Feb 8, 2024',
    readTime: '6 min read',
    category: 'Test Prep'
  },
  {
    id: '4',
    title: 'Grammar Rules That Appear Most on the SAT Writing Section',
    excerpt: 'Focus your study time on the grammar concepts that matter most. These rules appear repeatedly on the SAT and mastering them guarantees points.',
    date: 'Feb 5, 2024',
    readTime: '8 min read',
    category: 'Writing Tips'
  },
  {
    id: '5',
    title: 'Creating an Effective Study Schedule for SAT Prep',
    excerpt: 'Learn how to structure your preparation time for maximum efficiency. Discover the optimal balance between content review and practice testing.',
    date: 'Feb 1, 2024',
    readTime: '6 min read',
    category: 'Study Plans'
  },
  {
    id: '6',
    title: 'Common SAT Math Mistakes and How to Avoid Them',
    excerpt: 'Identify and eliminate the most frequent errors that cost students points. Learn from others\' mistakes to improve your own performance.',
    date: 'Jan 28, 2024',
    readTime: '9 min read',
    category: 'Math Tips'
  }
];

export const faqs: FAQ[] = [
  {
    id: '1',
    question: 'How many times can I take the SAT?',
    answer: 'You can take the SAT as many times as you want. Most colleges consider your highest score, though some look at all scores. We recommend taking it no more than 3-4 times to avoid test fatigue.',
    category: 'General'
  },
  {
    id: '2',
    question: 'What is a good SAT score?',
    answer: 'A good SAT score depends on your target colleges. The average score is around 1050, but competitive schools often look for scores above 1200-1300. Top-tier universities typically expect scores of 1400 or higher.',
    category: 'Scoring'
  },
  {
    id: '3',
    question: 'How long should I study for the SAT?',
    answer: 'Most students benefit from 2-4 months of consistent preparation, studying 1-2 hours per day, 4-5 days per week. The exact timeline depends on your starting score and target improvement.',
    category: 'Preparation'
  },
  {
    id: '4',
    question: 'Can I use a calculator on the SAT?',
    answer: 'Yes, you can use a calculator on one portion of the Math section, but not on the no-calculator math portion or the Reading and Writing sections. Make sure your calculator is approved by College Board.',
    category: 'Test Day'
  },
  {
    id: '5',
    question: 'What should I bring on test day?',
    answer: 'Bring your admission ticket, valid photo ID, approved calculator with extra batteries, No. 2 pencils, and an eraser. Snacks and drinks are allowed during breaks.',
    category: 'Test Day'
  },
  {
    id: '6',
    question: 'How is the SAT scored?',
    answer: 'The SAT is scored on a scale of 400-1600, with separate scores for Math (200-800) and Evidence-Based Reading and Writing (200-800). There is no penalty for wrong answers.',
    category: 'Scoring'
  },
  {
    id: '7',
    question: 'When should I start preparing for the SAT?',
    answer: 'Most students start preparing in their junior year, but you can begin as early as sophomore year. Starting earlier allows for more gradual improvement and less stress.',
    category: 'Preparation'
  },
  {
    id: '8',
    question: 'Do I need to take the SAT Essay?',
    answer: 'The SAT Essay is optional and has been discontinued as of June 2021. Most colleges no longer require it, but check with your target schools to be sure.',
    category: 'General'
  },
  {
    id: '9',
    question: 'How do I register for the SAT?',
    answer: 'Register online at the College Board website. You\'ll need to create an account, choose a test date and location, and pay the registration fee. Register early as popular test centers fill up quickly.',
    category: 'General'
  },
  {
    id: '10',
    question: 'What if I need accommodations for the SAT?',
    answer: 'Students with documented disabilities can request accommodations through College Board\'s Services for Students with Disabilities (SSD). Apply well in advance as the approval process takes time.',
    category: 'Test Day'
  }
];