export interface TestSection {
  id: string;
  title: string;
  description: string;
  duration: number;
  questions: number;
  topics: string[];
}

export interface PracticeQuestion {
  id: string;
  section: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface StudyPlan {
  id: string;
  title: string;
  duration: string;
  description: string;
  tasks: string[];
}

export interface TestDate {
  date: string;
  registrationDeadline: string;
  lateRegistrationDeadline: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  date: string;
  readTime: string;
  category: string;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: string;
}