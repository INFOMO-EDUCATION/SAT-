import React, { useState } from 'react';
import { Calendar, Clock, Tag, TrendingUp, BookOpen, Calculator } from 'lucide-react';
import { blogPosts } from '../data/mockData';

const Blog: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', 'Math Tips', 'Reading Strategies', 'Writing Tips', 'Test Prep', 'Study Plans'];

  const filteredPosts = selectedCategory === 'All' 
    ? blogPosts 
    : blogPosts.filter(post => post.category === selectedCategory);

  const featuredPost = blogPosts[0];

  return (
    <div className="space-y-12">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">SAT Prep Blog</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Expert tips, strategies, and insights to help you excel on the SAT exam. Stay updated with the latest test prep advice from our team of educators.
        </p>
      </div>

      {/* Featured Post */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100">
        <div className="md:flex">
          <div className="md:w-1/3 bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center p-8">
            <div className="text-center text-white">
              <BookOpen className="h-16 w-16 mx-auto mb-4" />
              <p className="text-lg font-semibold">Featured Article</p>
            </div>
          </div>
          <div className="md:w-2/3 p-8">
            <div className="flex items-center space-x-4 mb-4">
              <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                {featuredPost.category}
              </span>
              <div className="flex items-center text-gray-500 text-sm">
                <Calendar className="h-4 w-4 mr-1" />
                {featuredPost.date}
              </div>
              <div className="flex items-center text-gray-500 text-sm">
                <Clock className="h-4 w-4 mr-1" />
                {featuredPost.readTime}
              </div>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-3">{featuredPost.title}</h2>
            <p className="text-gray-600 mb-4 leading-relaxed">{featuredPost.excerpt}</p>
            <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200">
              Read Full Article
            </button>
          </div>
        </div>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-3 justify-center">
        {categories.map(category => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-full font-medium transition-colors duration-200 ${
              selectedCategory === category
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Blog Posts Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredPosts.slice(1).map((post) => (
          <article key={post.id} className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100 hover:shadow-xl transition-shadow duration-300">
            <div className="h-48 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
              {post.category === 'Math Tips' ? (
                <Calculator className="h-12 w-12 text-gray-400" />
              ) : post.category === 'Reading Strategies' ? (
                <BookOpen className="h-12 w-12 text-gray-400" />
              ) : (
                <TrendingUp className="h-12 w-12 text-gray-400" />
              )}
            </div>
            
            <div className="p-6">
              <div className="flex items-center space-x-3 mb-3">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  post.category === 'Math Tips' ? 'bg-blue-100 text-blue-800' :
                  post.category === 'Reading Strategies' ? 'bg-green-100 text-green-800' :
                  post.category === 'Writing Tips' ? 'bg-purple-100 text-purple-800' :
                  post.category === 'Study Plans' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-orange-100 text-orange-800'
                }`}>
                  {post.category}
                </span>
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-2 line-clamp-2">{post.title}</h3>
              <p className="text-gray-600 mb-4 line-clamp-3 leading-relaxed">{post.excerpt}</p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    {post.date}
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {post.readTime}
                  </div>
                </div>
                <button className="text-blue-600 font-medium hover:text-blue-700 transition-colors duration-200">
                  Read More →
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>

      {/* Load More */}
      <div className="text-center">
        <button className="bg-gray-100 text-gray-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-200 transition-colors duration-200">
          Load More Articles
        </button>
      </div>

      {/* Popular Topics */}
      <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">Popular Topics</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { title: 'Math Formula Sheets', icon: Calculator, color: 'blue' },
            { title: 'Reading Comprehension', icon: BookOpen, color: 'green' },
            { title: 'Test Day Tips', icon: TrendingUp, color: 'purple' },
            { title: 'Score Improvement', icon: Tag, color: 'orange' }
          ].map((topic, index) => {
            const Icon = topic.icon;
            return (
              <div key={index} className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200 cursor-pointer">
                <div className={`w-10 h-10 rounded-lg bg-${topic.color}-100 flex items-center justify-center mb-3`}>
                  <Icon className={`h-5 w-5 text-${topic.color}-600`} />
                </div>
                <h3 className="font-semibold text-gray-900">{topic.title}</h3>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Blog;