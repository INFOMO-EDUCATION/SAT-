import React, { useState } from 'react';
import { Timer, BarChart3, Target, TrendingUp, CheckCircle, Clock, Calendar, Award } from 'lucide-react';
import { calculateSATScore, getScorePercentile, getTargetScoreRecommendation } from '../utils/scoreCalculator';
import type { UserProgress } from '../types';

const PrepTools: React.FC = () => {
  const [activeTab, setActiveTab] = useState('mock-test');
  const [scoreInputs, setScoreInputs] = useState({
    reading: 30,
    writing: 25,
    math: 35
  });

  const [userProgress] = useState<UserProgress>({
    totalQuestions: 485,
    correctAnswers: 325,
    studyTime: 48,
    practiceTests: 7,
    targetScore: 1350
  });

  const calculatedScore = calculateSATScore(scoreInputs);
  const percentile = getScorePercentile(calculatedScore.total);
  const recommendation = getTargetScoreRecommendation(calculatedScore.total);

  const mockTests = [
    {
      id: 1,
      title: 'Full Practice Test #1',
      duration: '3 hours',
      questions: 154,
      difficulty: 'Official',
      completed: true,
      score: 1280
    },
    {
      id: 2,
      title: 'Full Practice Test #2',
      duration: '3 hours',
      questions: 154,
      difficulty: 'Official',
      completed: true,
      score: 1320
    },
    {
      id: 3,
      title: 'Full Practice Test #3',
      duration: '3 hours',
      questions: 154,
      difficulty: 'Official',
      completed: false,
      score: null
    },
    {
      id: 4,
      title: 'Math Section Practice',
      duration: '80 minutes',
      questions: 58,
      difficulty: 'Adaptive',
      completed: false,
      score: null
    }
  ];

  const renderMockTests = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Practice Tests</h2>
        <p className="text-gray-600">Take full-length practice tests to simulate the real SAT experience</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {mockTests.map((test) => (
          <div
            key={test.id}
            className={`bg-white p-6 rounded-xl shadow-lg border-2 transition-all duration-200 ${
              test.completed 
                ? 'border-green-200 hover:border-green-300' 
                : 'border-gray-200 hover:border-blue-300 hover:shadow-xl'
            }`}
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{test.title}</h3>
                <div className="flex items-center space-x-4 mt-2 text-sm text-gray-600">
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{test.duration}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Target className="h-4 w-4" />
                    <span>{test.questions} questions</span>
                  </div>
                </div>
              </div>
              {test.completed && (
                <div className="text-right">
                  <CheckCircle className="h-6 w-6 text-green-600 mb-1" />
                  <div className="text-lg font-bold text-green-600">{test.score}</div>
                </div>
              )}
            </div>

            <div className="mb-4">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                test.difficulty === 'Official' 
                  ? 'bg-blue-100 text-blue-800'
                  : 'bg-purple-100 text-purple-800'
              }`}>
                {test.difficulty}
              </span>
            </div>

            <button
              className={`w-full py-2 px-4 rounded-lg font-semibold transition-colors duration-200 ${
                test.completed
                  ? 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              {test.completed ? 'Review Results' : 'Start Test'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );

  const renderProgressDashboard = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Progress Dashboard</h2>
        <p className="text-gray-600">Track your improvement and stay motivated</p>
      </div>

      {/* Key Metrics */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl">
          <div className="flex items-center justify-between mb-2">
            <Target className="h-8 w-8 text-blue-600" />
            <span className="text-2xl font-bold text-blue-600">{userProgress.targetScore}</span>
          </div>
          <p className="text-gray-700 font-medium">Target Score</p>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl">
          <div className="flex items-center justify-between mb-2">
            <CheckCircle className="h-8 w-8 text-green-600" />
            <span className="text-2xl font-bold text-green-600">
              {Math.round((userProgress.correctAnswers / userProgress.totalQuestions) * 100)}%
            </span>
          </div>
          <p className="text-gray-700 font-medium">Accuracy Rate</p>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl">
          <div className="flex items-center justify-between mb-2">
            <Clock className="h-8 w-8 text-purple-600" />
            <span className="text-2xl font-bold text-purple-600">{userProgress.studyTime}</span>
          </div>
          <p className="text-gray-700 font-medium">Hours Studied</p>
        </div>

        <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-xl">
          <div className="flex items-center justify-between mb-2">
            <Award className="h-8 w-8 text-orange-600" />
            <span className="text-2xl font-bold text-orange-600">{userProgress.practiceTests}</span>
          </div>
          <p className="text-gray-700 font-medium">Tests Completed</p>
        </div>
      </div>

      {/* Progress Chart Placeholder */}
      <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-100">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Score Progress Over Time</h3>
        <div className="bg-gradient-to-br from-gray-50 to-gray-100 h-64 rounded-lg flex items-center justify-center">
          <div className="text-center">
            <BarChart3 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Score tracking chart would appear here</p>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-100">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Recent Activity</h3>
        <div className="space-y-4">
          {[
            { action: 'Completed Practice Test #2', score: 1320, date: '2 days ago' },
            { action: 'Studied Math formulas', score: null, date: '3 days ago' },
            { action: 'Completed Reading practice', score: 680, date: '5 days ago' },
            { action: 'Took diagnostic test', score: 1200, date: '1 week ago' }
          ].map((activity, index) => (
            <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">{activity.action}</p>
                <p className="text-sm text-gray-600">{activity.date}</p>
              </div>
              {activity.score && (
                <div className="text-right">
                  <span className="font-bold text-blue-600">{activity.score}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderScoreCalculator = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Score Calculator</h2>
        <p className="text-gray-600">Estimate your SAT score based on correct answers</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Input Section */}
        <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-100">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Enter Your Correct Answers</h3>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Reading (out of 52)
              </label>
              <input
                type="number"
                min="0"
                max="52"
                value={scoreInputs.reading}
                onChange={(e) => setScoreInputs({...scoreInputs, reading: parseInt(e.target.value) || 0})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Writing (out of 44)
              </label>
              <input
                type="number"
                min="0"
                max="44"
                value={scoreInputs.writing}
                onChange={(e) => setScoreInputs({...scoreInputs, writing: parseInt(e.target.value) || 0})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Math (out of 58)
              </label>
              <input
                type="number"
                min="0"
                max="58"
                value={scoreInputs.math}
                onChange={(e) => setScoreInputs({...scoreInputs, math: parseInt(e.target.value) || 0})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
        </div>

        {/* Results Section */}
        <div className="space-y-6">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-8 rounded-xl">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Your Estimated Scores</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Reading:</span>
                <span className="text-2xl font-bold text-blue-600">{calculatedScore.reading}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Writing:</span>
                <span className="text-2xl font-bold text-blue-600">{calculatedScore.writing}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Math:</span>
                <span className="text-2xl font-bold text-blue-600">{calculatedScore.math}</span>
              </div>
              <hr className="border-gray-300" />
              <div className="flex justify-between items-center">
                <span className="font-semibold text-gray-900">Total:</span>
                <span className="text-3xl font-bold text-blue-600">{calculatedScore.total}</span>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl">
            <h4 className="font-semibold text-gray-900 mb-2">Percentile Ranking</h4>
            <p className="text-2xl font-bold text-green-600">{percentile}th percentile</p>
            <p className="text-sm text-gray-600 mt-1">
              You scored better than {percentile}% of test takers
            </p>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl">
            <h4 className="font-semibold text-gray-900 mb-2">Improvement Recommendation</h4>
            <p className="text-lg font-bold text-purple-600">
              Target: {recommendation.recommended} (+{recommendation.improvement})
            </p>
            <p className="text-sm text-gray-600 mt-1">
              Estimated timeline: {recommendation.timeline}
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  const tabs = [
    { id: 'mock-test', label: 'Mock Tests', icon: Timer },
    { id: 'progress', label: 'Progress', icon: TrendingUp },
    { id: 'calculator', label: 'Score Calculator', icon: BarChart3 }
  ];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Preparation Tools</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Practice with realistic tests, track your progress, and calculate target scores.
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-semibold transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
              }`}
            >
              <Icon className="h-5 w-5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="min-h-[500px]">
        {activeTab === 'mock-test' && renderMockTests()}
        {activeTab === 'progress' && renderProgressDashboard()}
        {activeTab === 'calculator' && renderScoreCalculator()}
      </div>
    </div>
  );
};

export default PrepTools;