import React, { useState } from 'react';
import { Clock, FileText, Lightbulb, CheckCircle, AlertTriangle, Star, Target, BookOpen, Calculator } from 'lucide-react';
import { testSections } from '../data/mockData';

const TestSections: React.FC = () => {
  const [activeSection, setActiveSection] = useState('reading');

  const strategies = {
    reading: [
      'Read the passage before looking at questions to understand the main idea',
      'Underline key information, transitions, and the author\'s main arguments',
      'Eliminate clearly wrong answer choices to improve your odds',
      'Always look for evidence in the passage to support your answer choice',
      'Manage your time: spend about 13 minutes per passage including questions',
      'Pay attention to tone, mood, and the author\'s perspective'
    ],
    writing: [
      'Read the entire sentence, not just the underlined portion for context',
      'Choose the most concise answer that maintains clarity and meaning',
      'Pay attention to transition words and how sentences flow together',
      'Check for parallel structure in lists and series',
      'Consider the context of the entire paragraph when making choices',
      'Trust your ear - if something sounds wrong, it probably is'
    ],
    math: [
      'Read word problems carefully and identify exactly what\'s being asked',
      'Use the calculator strategically, not for simple arithmetic',
      'Check your work by plugging answers back into original equations',
      'Draw diagrams for geometry problems to visualize the solution',
      'Don\'t spend too long on any one question - move on and come back',
      'Look for shortcuts and patterns in multiple choice answers'
    ]
  };

  const commonMistakes = {
    reading: [
      'Not reading the passage thoroughly before attempting questions',
      'Choosing answers based on outside knowledge instead of the text',
      'Misinterpreting the main idea or author\'s tone and perspective',
      'Running out of time due to poor pacing and time management',
      'Overthinking questions and changing correct first instincts',
      'Ignoring context clues that help determine word meanings'
    ],
    writing: [
      'Choosing the longest answer thinking it\'s more complete or correct',
      'Not considering the context of surrounding sentences and paragraphs',
      'Confusing commonly misused words (their/there/they\'re, its/it\'s)',
      'Ignoring punctuation rules and comma usage guidelines',
      'Making changes that alter the intended meaning of the passage',
      'Not checking if the answer maintains the passage\'s style and tone'
    ],
    math: [
      'Making careless calculation errors due to rushing',
      'Not showing work and losing track of multi-step solutions',
      'Misreading word problems or misinterpreting diagrams',
      'Forgetting to answer the actual question being asked',
      'Using the calculator when mental math would be faster',
      'Not checking if answers make sense in the context of the problem'
    ]
  };

  const tips = {
    reading: [
      'Practice active reading by summarizing each paragraph mentally',
      'Focus on the first and last sentences of paragraphs for main ideas',
      'Look for signal words that indicate contrast, cause-effect, or examples',
      'Practice with passages from various subjects to build familiarity'
    ],
    writing: [
      'Learn the most common grammar rules tested on the SAT',
      'Practice identifying redundancy and wordiness in sentences',
      'Understand how to use punctuation to connect and separate ideas',
      'Read quality writing to develop an ear for proper English'
    ],
    math: [
      'Memorize key formulas and practice applying them quickly',
      'Learn to recognize common problem types and their solution methods',
      'Practice mental math to improve speed and accuracy',
      'Use estimation to check if your answers are reasonable'
    ]
  };

  const currentSection = testSections.find(section => section.id === activeSection)!;

  return (
    <div className="space-y-12">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">SAT Test Sections</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Master each section of the SAT with detailed breakdowns, proven strategies, and expert tips to maximize your score.
        </p>
      </div>

      {/* Section Selector */}
      <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
        {testSections.map((section) => {
          const Icon = section.id === 'reading' ? BookOpen : section.id === 'writing' ? Target : Calculator;
          return (
            <button
              key={section.id}
              onClick={() => setActiveSection(section.id)}
              className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-semibold transition-all duration-200 ${
                activeSection === section.id
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
              }`}
            >
              <Icon className="h-5 w-5" />
              <span>{section.title}</span>
            </button>
          );
        })}
      </div>

      {/* Section Overview */}
      <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">{currentSection.title}</h2>
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">{currentSection.description}</p>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Clock className="h-6 w-6 text-blue-600" />
                <span className="text-gray-700">
                  <strong>{currentSection.duration} minutes</strong> for {currentSection.questions} questions
                </span>
              </div>
              
              <div className="flex items-center space-x-3">
                <FileText className="h-6 w-6 text-green-600" />
                <span className="text-gray-700">
                  <strong>{(currentSection.duration / currentSection.questions).toFixed(1)} minutes</strong> per question on average
                </span>
              </div>

              <div className="flex items-center space-x-3">
                <Target className="h-6 w-6 text-purple-600" />
                <span className="text-gray-700">
                  <strong>Score Range:</strong> {currentSection.id === 'math' ? '200-800' : 'Combined 200-800 (with other section)'}
                </span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Topics Covered</h3>
            <div className="space-y-3">
              {currentSection.topics.map((topic, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700 font-medium">{topic}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Strategies */}
      <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-8">
        <div className="flex items-center mb-6">
          <Lightbulb className="h-8 w-8 text-green-600 mr-3" />
          <h3 className="text-2xl font-bold text-gray-900">Proven Strategies</h3>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          {strategies[activeSection as keyof typeof strategies].map((strategy, index) => (
            <div key={index} className="flex items-start space-x-3 bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200">
              <Star className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
              <p className="text-gray-700 leading-relaxed">{strategy}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Common Mistakes */}
      <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl p-8">
        <div className="flex items-center mb-6">
          <AlertTriangle className="h-8 w-8 text-orange-600 mr-3" />
          <h3 className="text-2xl font-bold text-gray-900">Common Pitfalls to Avoid</h3>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          {commonMistakes[activeSection as keyof typeof commonMistakes].map((mistake, index) => (
            <div key={index} className="flex items-start space-x-3 bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200">
              <AlertTriangle className="h-5 w-5 text-orange-600 mt-0.5 flex-shrink-0" />
              <p className="text-gray-700 leading-relaxed">{mistake}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Additional Tips */}
      <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-8">
        <div className="flex items-center mb-6">
          <Target className="h-8 w-8 text-blue-600 mr-3" />
          <h3 className="text-2xl font-bold text-gray-900">Pro Tips for Success</h3>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          {tips[activeSection as keyof typeof tips].map((tip, index) => (
            <div key={index} className="flex items-start space-x-3 bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200">
              <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <p className="text-gray-700 leading-relaxed">{tip}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Success Stories */}
      <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
        <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Success Stories</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-lg text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">1420</div>
            <div className="text-sm text-gray-600 mb-3">Final Score</div>
            <p className="text-gray-700 text-sm italic mb-2">
              "The reading strategies helped me improve from 650 to 720 in just 2 months!"
            </p>
            <p className="text-gray-600 text-xs">- Sarah M., Class of 2024</p>
          </div>

          <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-lg text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">1380</div>
            <div className="text-sm text-gray-600 mb-3">Final Score</div>
            <p className="text-gray-700 text-sm italic mb-2">
              "The writing section tips were game-changers. I went from 580 to 690!"
            </p>
            <p className="text-gray-600 text-xs">- Marcus T., Class of 2024</p>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-lg text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">1510</div>
            <div className="text-sm text-gray-600 mb-3">Final Score</div>
            <p className="text-gray-700 text-sm italic mb-2">
              "Perfect math score! The practice problems were exactly like the real test."
            </p>
            <p className="text-gray-600 text-xs">- Emily R., Class of 2024</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestSections;