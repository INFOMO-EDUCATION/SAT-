import React from 'react';
import { Calendar, Clock, Users, TrendingUp, BookOpen, Target, Calculator, Award, CheckCircle } from 'lucide-react';
import { testDates } from '../data/mockData';

interface HomePageProps {
  onSectionChange: (section: string) => void;
}

const HomePage: React.FC<HomePageProps> = ({ onSectionChange }) => {
  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-blue-100 py-16 px-4 sm:px-6 lg:px-8 rounded-2xl">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Master the SAT with
            <span className="text-blue-600"> Confidence</span>
          </h1>
          <p className="text-xl text-gray-700 mb-8 max-w-3xl mx-auto leading-relaxed">
            Comprehensive test preparation resources, practice questions, and personalized study plans 
            to help you achieve your target SAT score and unlock your college dreams.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => onSectionChange('resources')}
              className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              Start Learning Now
            </button>
            <button 
              onClick={() => onSectionChange('sections')}
              className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold border-2 border-blue-600 hover:bg-blue-50 transition-colors duration-200"
            >
              Explore Test Sections
            </button>
          </div>
        </div>
      </section>

      {/* SAT Overview */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-4">Understanding the SAT</h2>
          <p className="text-lg text-gray-600 text-center mb-12 max-w-3xl mx-auto">
            The SAT is a standardized test widely used for college admissions. Get familiar with its structure and requirements.
          </p>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
              <div className="flex items-center mb-4">
                <BookOpen className="h-8 w-8 text-green-600" />
                <h3 className="text-xl font-semibold text-gray-900 ml-3">Reading</h3>
              </div>
              <p className="text-gray-600 mb-4 font-medium">52 questions in 65 minutes</p>
              <p className="text-gray-700 leading-relaxed">Tests reading comprehension, vocabulary in context, and analysis of evidence across literature, history, and science passages.</p>
              <div className="mt-4 pt-4 border-t border-gray-100">
                <span className="text-sm font-medium text-green-600">Score Range: 200-800</span>
              </div>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
              <div className="flex items-center mb-4">
                <Target className="h-8 w-8 text-blue-600" />
                <h3 className="text-xl font-semibold text-gray-900 ml-3">Writing & Language</h3>
              </div>
              <p className="text-gray-600 mb-4 font-medium">44 questions in 35 minutes</p>
              <p className="text-gray-700 leading-relaxed">Focuses on grammar, usage, and rhetorical skills in written passages, testing your ability to improve texts.</p>
              <div className="mt-4 pt-4 border-t border-gray-100">
                <span className="text-sm font-medium text-blue-600">Combined with Reading: 200-800</span>
              </div>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
              <div className="flex items-center mb-4">
                <Calculator className="h-8 w-8 text-orange-600" />
                <h3 className="text-xl font-semibold text-gray-900 ml-3">Mathematics</h3>
              </div>
              <p className="text-gray-600 mb-4 font-medium">58 questions in 80 minutes</p>
              <p className="text-gray-700 leading-relaxed">Covers algebra, geometry, trigonometry, and data analysis with both calculator and no-calculator sections.</p>
              <div className="mt-4 pt-4 border-t border-gray-100">
                <span className="text-sm font-medium text-orange-600">Score Range: 200-800</span>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-8">
            <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl p-6 inline-block">
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Total SAT Score</h4>
              <p className="text-3xl font-bold text-blue-600">400 - 1600</p>
              <p className="text-sm text-gray-600 mt-1">Evidence-Based Reading & Writing + Math</p>
            </div>
          </div>
        </div>
      </section>

      {/* Test Dates */}
      <section className="bg-gray-50 py-16 rounded-2xl">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-4">Upcoming Test Dates</h2>
          <p className="text-lg text-gray-600 text-center mb-12">
            Plan ahead and register early for your preferred test date and location.
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testDates.map((date, index) => (
              <div key={index} className="bg-white p-6 rounded-xl shadow-md border border-gray-100 hover:shadow-lg transition-shadow duration-200">
                <div className="flex items-center mb-4">
                  <Calendar className="h-6 w-6 text-blue-600" />
                  <h3 className="text-lg font-semibold text-gray-900 ml-2">Test Date</h3>
                </div>
                <p className="text-xl font-bold text-blue-600 mb-4">{date.date}</p>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Registration Deadline:</span>
                    <span>{date.registrationDeadline}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Late Registration:</span>
                    <span>{date.lateRegistrationDeadline}</span>
                  </div>
                </div>
                <button className="w-full mt-4 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium">
                  Register Now
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Stats */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-4">Why Choose SAT Prep Pro?</h2>
          <p className="text-lg text-gray-600 text-center mb-12 max-w-3xl mx-auto">
            Join thousands of successful students who have achieved their target scores with our proven methods.
          </p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">50,000+</h3>
              <p className="text-gray-600">Students Helped</p>
            </div>
            
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">150+</h3>
              <p className="text-gray-600">Average Score Increase</p>
            </div>
            
            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">2,000+</h3>
              <p className="text-gray-600">Practice Questions</p>
            </div>
            
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">95%</h3>
              <p className="text-gray-600">Success Rate</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Highlight */}
      <section className="bg-gradient-to-br from-purple-50 to-purple-100 py-16 rounded-2xl">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">Everything You Need to Succeed</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Target className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Comprehensive Test Sections</h3>
              <p className="text-gray-600">Detailed breakdowns of Reading, Writing, and Math sections with proven strategies.</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <BookOpen className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Rich Study Resources</h3>
              <p className="text-gray-600">Practice questions, study plans, video tutorials, and downloadable materials.</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                <CheckCircle className="h-6 w-6 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Expert Guidance</h3>
              <p className="text-gray-600">FAQ section, blog with tips, and comprehensive support for all your questions.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 py-16 px-4 sm:px-6 lg:px-8 rounded-2xl text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-white mb-6">Ready to Start Your SAT Journey?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of students who have improved their scores with our comprehensive preparation resources.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => onSectionChange('resources')}
              className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-50 transition-colors duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              Get Started Today
            </button>
            <button 
              onClick={() => onSectionChange('blog')}
              className="bg-blue-500 text-white px-8 py-4 rounded-lg text-lg font-semibold border-2 border-blue-400 hover:bg-blue-400 transition-colors duration-200"
            >
              Read Success Tips
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;