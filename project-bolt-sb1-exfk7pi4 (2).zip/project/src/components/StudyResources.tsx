import React, { useState } from 'react';
import { Download, Play, BookOpen, Calculator, FileText, CheckCircle, X, Clock, Star } from 'lucide-react';
import { practiceQuestions, studyPlans } from '../data/mockData';

const StudyResources: React.FC = () => {
  const [selectedQuestion, setSelectedQuestion] = useState<string | null>(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('All');

  const resources = [
    {
      title: 'Essential Math Formulas',
      description: 'Complete collection of algebra, geometry, and trigonometry formulas',
      type: 'PDF',
      size: '2.1 MB',
      icon: Calculator,
      color: 'blue',
      downloads: '15.2K'
    },
    {
      title: 'SAT Vocabulary Builder',
      description: '500 most common SAT words with definitions and example sentences',
      type: 'PDF',
      size: '1.8 MB',
      icon: BookOpen,
      color: 'green',
      downloads: '12.8K'
    },
    {
      title: 'Writing & Grammar Guide',
      description: 'Comprehensive guide to grammar rules and writing strategies',
      type: 'PDF',
      size: '3.2 MB',
      icon: FileText,
      color: 'purple',
      downloads: '9.5K'
    },
    {
      title: 'Reading Comprehension Workbook',
      description: 'Practice passages with detailed analysis and strategies',
      type: 'PDF',
      size: '4.1 MB',
      icon: BookOpen,
      color: 'orange',
      downloads: '11.3K'
    },
    {
      title: 'Test Day Checklist',
      description: 'Everything you need to know for test day success',
      type: 'PDF',
      size: '0.8 MB',
      icon: CheckCircle,
      color: 'green',
      downloads: '8.7K'
    },
    {
      title: 'Score Improvement Tracker',
      description: 'Track your progress and identify areas for improvement',
      type: 'PDF',
      size: '1.2 MB',
      icon: Star,
      color: 'yellow',
      downloads: '6.9K'
    }
  ];

  const videoTutorials = [
    {
      title: 'Quadratic Equations Mastery',
      duration: '15:30',
      views: '12.5K',
      topic: 'Math',
      difficulty: 'Intermediate',
      description: 'Learn to solve quadratic equations using multiple methods'
    },
    {
      title: 'Reading Comprehension Strategies',
      duration: '22:15',
      views: '18.2K',
      topic: 'Reading',
      difficulty: 'Beginner',
      description: 'Master active reading techniques for better comprehension'
    },
    {
      title: 'Grammar Rules You Need to Know',
      duration: '18:45',
      views: '9.8K',
      topic: 'Writing',
      difficulty: 'Beginner',
      description: 'Essential grammar concepts for the Writing section'
    },
    {
      title: 'Advanced Algebra Concepts',
      duration: '28:12',
      views: '7.3K',
      topic: 'Math',
      difficulty: 'Advanced',
      description: 'Complex algebraic concepts and problem-solving techniques'
    },
    {
      title: 'Essay Writing Fundamentals',
      duration: '20:30',
      views: '11.1K',
      topic: 'Writing',
      difficulty: 'Intermediate',
      description: 'Structure and develop compelling essays'
    },
    {
      title: 'Data Analysis and Statistics',
      duration: '25:45',
      views: '8.9K',
      topic: 'Math',
      difficulty: 'Intermediate',
      description: 'Interpret charts, graphs, and statistical data'
    }
  ];

  const categories = ['All', 'Math', 'Reading', 'Writing'];
  
  const filteredQuestions = selectedCategory === 'All' 
    ? practiceQuestions 
    : practiceQuestions.filter(q => 
        (selectedCategory === 'Math' && q.section === 'math') ||
        (selectedCategory === 'Reading' && q.section === 'reading') ||
        (selectedCategory === 'Writing' && q.section === 'writing')
      );

  const currentQuestion = practiceQuestions.find(q => q.id === selectedQuestion);

  return (
    <div className="space-y-12">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Study Resources</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Access comprehensive study materials, practice questions, video tutorials, and personalized study plans to excel on the SAT.
        </p>
      </div>

      {/* Practice Questions */}
      <section className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 sm:mb-0">Practice Questions</h2>
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors duration-200 ${
                  selectedCategory === category
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          {filteredQuestions.map((question) => (
            <div
              key={question.id}
              className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow duration-200 cursor-pointer hover:border-blue-300"
              onClick={() => {
                setSelectedQuestion(question.id);
                setShowAnswer(false);
              }}
            >
              <div className="flex items-center justify-between mb-3">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  question.section === 'math' 
                    ? 'bg-blue-100 text-blue-800'
                    : question.section === 'reading'
                    ? 'bg-green-100 text-green-800'
                    : 'bg-purple-100 text-purple-800'
                }`}>
                  {question.section === 'math' ? 'Math' : question.section === 'reading' ? 'Reading' : 'Writing'}
                </span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  question.difficulty === 'easy' 
                    ? 'bg-green-100 text-green-800'
                    : question.difficulty === 'medium'
                    ? 'bg-yellow-100 text-yellow-800'
                    : 'bg-red-100 text-red-800'
                }`}>
                  {question.difficulty}
                </span>
              </div>
              <p className="text-gray-700 font-medium mb-3 line-clamp-2">{question.question}</p>
              <button className="text-blue-600 text-sm font-medium hover:text-blue-700 transition-colors duration-200">
                Practice this question →
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Question Modal */}
      {selectedQuestion && currentQuestion && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold text-gray-900">Practice Question</h3>
                <button
                  onClick={() => setSelectedQuestion(null)}
                  className="text-gray-500 hover:text-gray-700 transition-colors duration-200"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
              
              <div className="mb-6">
                <div className="flex items-center space-x-3 mb-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    currentQuestion.section === 'math' 
                      ? 'bg-blue-100 text-blue-800'
                      : currentQuestion.section === 'reading'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-purple-100 text-purple-800'
                  }`}>
                    {currentQuestion.section === 'math' ? 'Math' : currentQuestion.section === 'reading' ? 'Reading' : 'Writing'}
                  </span>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    currentQuestion.difficulty === 'easy' 
                      ? 'bg-green-100 text-green-800'
                      : currentQuestion.difficulty === 'medium'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {currentQuestion.difficulty}
                  </span>
                </div>
                
                <p className="text-lg text-gray-800 mb-4 leading-relaxed">{currentQuestion.question}</p>
                <div className="space-y-2">
                  {currentQuestion.options.map((option, index) => (
                    <div
                      key={index}
                      className={`p-3 rounded-lg border-2 cursor-pointer transition-colors duration-200 ${
                        showAnswer && index === currentQuestion.correctAnswer
                          ? 'border-green-500 bg-green-50'
                          : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      <span className="font-medium">{String.fromCharCode(65 + index)}. </span>
                      {option}
                    </div>
                  ))}
                </div>
              </div>

              {!showAnswer ? (
                <button
                  onClick={() => setShowAnswer(true)}
                  className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200"
                >
                  Show Answer & Explanation
                </button>
              ) : (
                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <div className="flex items-center mb-2">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                    <span className="font-semibold text-green-800">
                      Correct Answer: {String.fromCharCode(65 + currentQuestion.correctAnswer)}
                    </span>
                  </div>
                  <p className="text-gray-700 leading-relaxed">{currentQuestion.explanation}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Downloadable Resources */}
      <section className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Downloadable Resources</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((resource, index) => {
            const Icon = resource.icon;
            return (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200">
                <div className={`w-12 h-12 rounded-lg bg-${resource.color}-100 flex items-center justify-center mb-4`}>
                  <Icon className={`h-6 w-6 text-${resource.color}-600`} />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{resource.title}</h3>
                <p className="text-gray-600 mb-4 text-sm leading-relaxed">{resource.description}</p>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs text-gray-500">{resource.type} • {resource.size}</span>
                  <span className="text-xs text-gray-500">{resource.downloads} downloads</span>
                </div>
                <button className="w-full flex items-center justify-center space-x-2 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200">
                  <Download className="h-4 w-4" />
                  <span>Download</span>
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* Video Tutorials */}
      <section className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Video Tutorials</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {videoTutorials.map((video, index) => (
            <div key={index} className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg overflow-hidden hover:shadow-md transition-shadow duration-200">
              <div className="bg-gray-800 h-32 flex items-center justify-center relative">
                <Play className="h-12 w-12 text-white" />
                <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
                  {video.duration}
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    video.topic === 'Math' 
                      ? 'bg-blue-100 text-blue-800'
                      : video.topic === 'Reading'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-purple-100 text-purple-800'
                  }`}>
                    {video.topic}
                  </span>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    video.difficulty === 'Beginner'
                      ? 'bg-green-100 text-green-800'
                      : video.difficulty === 'Intermediate'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {video.difficulty}
                  </span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{video.title}</h3>
                <p className="text-sm text-gray-600 mb-3">{video.description}</p>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{video.duration}</span>
                  </div>
                  <span>{video.views} views</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Study Plans */}
      <section className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Personalized Study Plans</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {studyPlans.map((plan) => (
            <div key={plan.id} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{plan.title}</h3>
              <p className="text-gray-600 mb-4 leading-relaxed">{plan.description}</p>
              <div className="mb-4">
                <span className="text-sm font-medium text-purple-600 bg-purple-100 px-3 py-1 rounded-full">
                  Duration: {plan.duration}
                </span>
              </div>
              <div className="space-y-2 mb-6">
                {plan.tasks.map((task, index) => (
                  <div key={index} className="flex items-start space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-gray-700 leading-relaxed">{task}</span>
                  </div>
                ))}
              </div>
              <button className="w-full bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 transition-colors duration-200 font-medium">
                Start This Plan
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default StudyResources;