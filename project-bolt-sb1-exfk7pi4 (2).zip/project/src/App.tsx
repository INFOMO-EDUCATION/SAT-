import React, { useState } from 'react';
import Header from './components/Header';
import HomePage from './components/HomePage';
import TestSections from './components/TestSections';
import StudyResources from './components/StudyResources';
import FAQ from './components/FAQ';
import Blog from './components/Blog';
import Footer from './components/Footer';

function App() {
  const [activeSection, setActiveSection] = useState('home');

  const renderActiveSection = () => {
    switch (activeSection) {
      case 'home':
        return <HomePage onSectionChange={setActiveSection} />;
      case 'sections':
        return <TestSections />;
      case 'resources':
        return <StudyResources />;
      case 'faq':
        return <FAQ />;
      case 'blog':
        return <Blog />;
      default:
        return <HomePage onSectionChange={setActiveSection} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header activeSection={activeSection} onSectionChange={setActiveSection} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderActiveSection()}
      </main>
      
      <Footer />
    </div>
  );
}

export default App;